# Fake Tiktok coin page [PC]

## Static page HTML CSS of tiktok coin store
Static page of the TikTok corner store French version [€]. You can grab the style to make your own online store. 
I am not responsible for your use of this repository, it is for informational and fun purposes only.

You only need to launch the index.html to get to the page.

I am aware that the project still has flaws, the modifications will be made one day when I will be available and I will not be lazy


## Prank your friends
You have the possibility to prank your friends, using the field to mark their nickname and a "Verification" button. This allows you to pretend to check if your friend is participating in your live to give them coins.

If you click on the left of the button, it will simulate an error that the user mentioned in the text field, has not sent you a tiktok gift.
Conversely, the right of the button will validate you, showing that the user has sent you a gift.

To end with a fake PayPal payment system, to finish the valve all the way by saying that he will receive the coins in a few hours


## Tips
You can go to the real [TikTok page](https://www.tiktok.com/coin?lang=fr) and keep it in history. This will allow you to mark the link over the localhost or file location :)

![Preview](/img/Preview.png)

![PreviewPayement](/img/PreviewPayment.png)